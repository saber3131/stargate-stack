# 星际之门 VPN · 东京主力节点（Always Free）
terraform {
  required_providers {
    oci = { source = "oracle/oci", version = ">= 5.0" }
  }
}

provider "oci" {}

data "oci_identity_tenancy" "t" { tenant_id = var.tenancy_ocid }
data "oci_identity_availability_domains" "ads" { compartment_id = var.tenancy_ocid }

variable "tenancy_ocid" { type = string }
variable "compartment_ocid" {
  type    = string
  default = ""
}
locals {
  compartment_id = var.compartment_ocid != "" ? var.compartment_ocid : var.tenancy_ocid
  ssh_public_key = "ssh-rsa AAAAB3NzaC1yc2EAAAADAQABAAABAQDKLViF2XnkCr+YFT8+qYhMr+H/jFwRO7ubWAJRBjKJWitQSmfqcrN7ZD3BS+/HDt9b/bfHi7tYDUoZh5ARo1fPflttsxrxeI5bfltkk1pgKuDTXCFErvPlmNIMIBA1aajytmFQIqg5wqVau91GNk4qAEjEfdd91KyQWLY7l1nfafv32B5BMFB5J9rSSJsXVT8gcM7m6DnPEck50x0WNqT2dPSvWY54qY4NRdA6F9sE2ZsyL/Amw82Yh8RhzHk3TtMZzSoaSD3eApuxpXcb1YyRb2Ul5lP8GB9NXcNGz+U7NIYOQicUWnTARUiKqlIzi3ljB6L1tgpF5R47XeslNRhn stargate-tokyo@zhenbai.one"
}

# Ubuntu 22.04 (aarch64, 适配 A1.Flex)
data "oci_core_images" "ubuntu" {
  compartment_id           = local.compartment_id
  operating_system         = "Canonical Ubuntu Linux"
  operating_system_version = "22.04"
  shape                    = "VM.Standard.A1.Flex"
  sort_by                  = "TIMECREATED"
  sort_order               = "DESC"
}

# 网络
resource "oci_core_vcn" "v" {
  compartment_id = local.compartment_id
  cidr_blocks    = ["10.0.0.0/16"]
  display_name   = "stargate-vcn"
  dns_label      = "stargate"
}
resource "oci_core_internet_gateway" "ig" {
  compartment_id = local.compartment_id
  vcn_id         = oci_core_vcn.v.id
  display_name   = "stargate-ig"
  enabled        = true
}
resource "oci_core_default_route_table" "rt" {
  manage_default_resource_id = oci_core_vcn.v.default_route_table_id
  display_name               = "stargate-rt"
  route_rules {
    destination       = "0.0.0.0/0"
    destination_type  = "CIDR_BLOCK"
    network_entity_id = oci_core_internet_gateway.ig.id
  }
}
resource "oci_core_security_list" "sl" {
  compartment_id = local.compartment_id
  vcn_id         = oci_core_vcn.v.id
  display_name   = "stargate-sl"

  ingress_security_rules {
    protocol = "1" # ICMP
    source   = "0.0.0.0/0"
  }
  ingress_security_rules {
    protocol = "6" # SSH
    source   = "0.0.0.0/0"
    tcp_options {
      min = 22
      max = 22
    }
  }
  ingress_security_rules {
    protocol    = "17" # WireGuard
    source      = "0.0.0.0/0"
    udp_options {
      min = 51820
      max = 51820
    }
  }
  ingress_security_rules {
    protocol    = "6" # shadowsocks
    source      = "0.0.0.0/0"
    tcp_options {
      min = 8388
      max = 8388
    }
  }
}

# 子网
resource "oci_core_subnet" "s" {
  compartment_id             = local.compartment_id
  vcn_id                     = oci_core_vcn.v.id
  cidr_block                 = "10.0.1.0/24"
  display_name               = "stargate-subnet"
  security_list_ids          = [oci_core_security_list.sl.id]
  route_table_id             = oci_core_default_route_table.rt.id
  dhcp_options_id            = oci_core_vcn.v.default_dhcp_options_id
}

# 东京主力节点：A1.Flex 满配 4核24G（免费额度全部给这一台 = 最强单节点）
resource "oci_core_instance" "tokyo" {
  availability_domain = data.oci_identity_availability_domains.ads.availability_domains[0].name
  compartment_id      = local.compartment_id
  display_name        = "stargate-tokyo"
  shape               = "VM.Standard.A1.Flex"

  shape_config {
    ocpus         = 4
    memory_in_gbs = 24
  }

  source_details {
    source_type             = "image"
    source_id               = data.oci_core_images.ubuntu.images[0].id
    boot_volume_size_in_gbs = 100
  }

  create_vnic_details {
    subnet_id        = oci_core_subnet.s.id
    assign_public_ip = true
    display_name     = "stargate-tokyo-vnic"
    hostname_label   = "stargate"
  }

  metadata = { ssh_authorized_keys = local.ssh_public_key }

  timeouts { create = "20m" }
}

output "server_public_ip" {
  value = oci_core_instance.tokyo.public_ip
}
output "ssh_command" {
  value = "ssh -i stargate-tokyo.key ubuntu@${oci_core_instance.tokyo.public_ip}"
}
